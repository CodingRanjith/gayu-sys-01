import 'package:dio/dio.dart';
import 'package:newsee/core/api/api_config.dart';

class ChifRemoteDatasource {
  final Dio dio;

  ChifRemoteDatasource({required this.dio});

  
  ChifWithUserId(Map<String, dynamic> payload) async {
    Response response = await dio.post(
      'MobileService/CIFSearch',
      data: {'Login': payload, 'token': ApiConfig.AUTH_TOKEN},
    );
    return response;
  }
}
