import 'dart:io';

import 'package:dio/dio.dart';
import 'package:newsee/Model/api_core/AsyncResponseHandler.dart';
import 'package:newsee/Model/api_core/auth_failure.dart';
import 'package:newsee/Model/api_core/failure.dart';
import 'package:newsee/Model/login_request.dart';
import 'package:newsee/feature/auth/data/datasource/auth_remote_datasource.dart';
import 'package:newsee/feature/auth/domain/model/user/auth_response_model.dart';
import 'package:newsee/feature/auth/domain/repository/auth_repository.dart';
import 'package:newsee/feature/cif/data/datasource/chif_remote_datasource.dart';
import 'package:newsee/feature/cif/domain/repository/auth_repository.dart';

class ChifRepositoryImpl implements ChifRepository {
  final ChifRemoteDatasource chifRemoteDatasource;

  ChifRepositoryImpl({required this.authRemoteDatasource});


  @override
  Future<ChifResponseHandler<Failure, ChifResponseModel>> cifWithFetch(
    LoginRequest req,
  ) async {
    try {
      Map<String, dynamic> payload = {
          "custId": req.custId,
          "uniqueId": "3",
          "cifId": "121212",
          "type": "borrower",
          "token": "U2FsdGVkX1/Wa6+JeCIOVLl8LTr8WUocMz8kIGXVbEI9Q32v7zRLrnnvAIeJIVV3"
      };

      print('Chif request payload => $payload');
      var response = await authRemoteDatasource.ChifWithUserId(payload);

      // process api response if it's success
      if (response.data['Success']) {
        var authResponse = AuthResponseModel.fromJson(
          response.data['responseData'],
        );
        print('AuthResponseModel.fromJson() => ${authResponse.toString()}');
        return AsyncResponseHandler.right(authResponse);
      } else {
        // api response success : false , process error message
        var errorMessage = response.data['ErrorMessage'];
        print('on Error request.data["ErrorMessage"] => $errorMessage');
        return AsyncResponseHandler.left(AuthFailure(message: errorMessage));
      }
    } on DioException catch (e) {
      // exception handler for server down
      if (e.error is SocketException) {
        return AsyncResponseHandler.left(
          AuthFailure(
            message: "Could not reach Server , Please try again in sometimes.",
          ),
        );
      }
      return AsyncResponseHandler.left(
        AuthFailure(message: "Exception Occured"),
      );
    } on Exception {
      return AsyncResponseHandler.left(
        AuthFailure(message: 'Authentication Failure'),
      );
    }
  }
}
