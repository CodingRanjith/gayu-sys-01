part of 'cif_bloc.dart';

sealed class CifEvent {}

final class CifSearch extends CifEvent {
  final CIFIDRequest cifidRequest;

  CifSearch({required this.cifidRequest});
}

