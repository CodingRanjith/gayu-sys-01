part of 'cif_bloc.dart';

enum ChifStatus { init, fetching, success, failure }

class ChifState extends Equatable {
  final ChifStatus? chifStatus;
  final ChifResponseModel? chifResponseModel;


  ChifState({
    required this.chifStatus,
    required this.chifResponseModel,
  });

  factory ChifState.init() => ChifState(
        chifStatus: ChifStatus.init,
        chifResponseModel: null,
        

      );

  ChifState copyWith({
    ChifStatus? status,
    ChifResponseModel? chifResponseModel,
  }) {
    return ChifState(
      chifStatus: status ?? this.chifStatus,
      chifResponseModel: chifResponseModel ?? this.chifResponseModel,
    );
  }

  @override
  List<Object?> get props => [
        chifStatus,
        chifResponseModel,
      ];
}
