
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:newsee/Model/api_core/AsyncResponseHandler.dart';
import 'package:newsee/Model/cif_request.dart';
import 'package:newsee/feature/cif/domain/model/user/chif_response_model.dart';
import 'package:newsee/feature/cif/domain/repository/auth_repository.dart';

part 'cif_event.dart';
part 'cif_state.dart';

final class ChifBloc extends Bloc<CifEvent, ChifState> {
  final ChifRepository authRepository;

  ChifBloc({required this.authRepository}) : super(ChifState.init()) {
    on<CifSearch>(onFetchData);
  }

  Future onFetchData(CifSearch event, Emitter emit) async {
    emit(state.copyWith(status: ChifStatus.fetching));

    AsyncResponseHandler response = await authRepository.fetchwithCifId(
      event.cifidRequest,
    );
    if (response.isRight()) {
      emit(
        state.copyWith(
          status: ChifStatus.success,
          chifResponseModel: response.right,
        ),
      );
    } else {
      print('auth failure response.left ');
      emit(
        state.copyWith(
          status: ChifStatus.failure,

        ),
      );
    }
  }


}
