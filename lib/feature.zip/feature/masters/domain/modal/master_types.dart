enum MasterTypes { lov, products, productschema }
